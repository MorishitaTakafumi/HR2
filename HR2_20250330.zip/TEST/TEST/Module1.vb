﻿Module Module1
    Sub Main()
        Dim a As New TopMenu
        Application.Run(a)
    End Sub

End Module
